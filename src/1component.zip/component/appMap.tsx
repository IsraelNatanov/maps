import React, { useEffect, useState } from "react";
import Map from "ol/Map";
import View from "ol/View";
import { get, fromLonLat } from "ol/proj";
import TileLayer from "ol/layer/Tile";
import Vector from "ol/layer/Vector";
import Point from "ol/geom/Point";
import OSM from "ol/source/OSM";
import Vectors from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import FullScreen from "ol/control/FullScreen";
import Select from "ol/interaction/Select";
import "ol/ol.css";
import { toLonLat } from "ol/proj";
import Draw from "ol/interaction/Draw";
import "./maps.css";
import axios from "axios";
import jgo from "../gho.json";
import fullJson from "../fullJson.json";
import Overlay from "ol/Overlay";
import MapBrowserEvent from "ol/MapBrowserEvent";
import Feature from "ol/Feature";
import { styleFunction, styleLineString } from "./function";

import ButtonHeader from "./buttonHeader";
import { useQuery } from "react-query";

import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import SplitButton from "./splitButton";

const format = new GeoJSON({ featureProjection: "EPSG:3857" });

const featuresss = format.readFeatures(jgo);
const featureFullJson = format.readFeatures(fullJson);
type IProps = {
  use: boolean;
  setUse: React.Dispatch<React.SetStateAction<boolean>>;
};

const AppMap: React.FC = () => {
  const arrPoint: Number[] = [];
  const [viewSites, setViewSites] = useState(false);

  // let [map,setMap] = useState<null|Map>()
  let map = new Map();

  const extent: any = get("EPSG:3857")!.getExtent().slice();
  extent[0] += extent[0];
  extent[2] += extent[2];

  const source = new Vectors();
  const sourcee = new Vectors();

  const vector = new Vector({
    source: source,
    style: styleLineString,
  });
  let mapSource = new Vectors();

  // let map: Map | null = null;
  function vectorLoader() {
    axios
      .get("http://localhost:9000/geojson")
      .then((res) => {
        console.log(res.data);
        const features = format.readFeatures(res.data);
        mapSource.addFeatures(features);
      })
      .catch((error) => console.log(error));
  }

  let overlay: Overlay | null = null;

  // let map = new Map();
  let vectorLayer = new Vector();

  // const queryRefrechLayer = () => {
  //   useQuery("refrechLayer", refreachLayer, {
  //     enabled: false,
  //   });
  // };
  useEffect(() => {
    map = new Map({
      target: "map-container",
      view: new View({
        center: fromLonLat([34.84517762144668, 32.167921158434325]),
        zoom: 16,
      }),
      layers: [
        new TileLayer({
          source: new OSM(),
        }),
        vector,
        // vectorLayer,
        // berlin,
        // fuul
      ],
    });

    // const marker = new Vector({
    //   source: new Vectors({
    //     features,
    //   }),

    //   style: styleMarker,
    // });

    const tooltip: HTMLElement | null = document.getElementById("tooltip");
    const positioning = "bottom-left";

    overlay = new Overlay({
      element: tooltip!,
      offset: [10, 0],
      positioning: positioning,
    });

    map.on("click", function (event: any) {
      let point = map!.getCoordinateFromPixel(event.pixel);
      let lonLat = toLonLat(point);
      arrPoint.push(lonLat[0]);
      arrPoint.push(lonLat[1]);
      console.log(arrPoint[0], 0);
      console.log(arrPoint[1], 1);
      console.log(arrPoint[arrPoint.length - 2], 3);
      console.log(arrPoint[arrPoint.length - 1], 4);
    });

    // map.addLayer(vectorLayer)
    // map.addLayer(marker);

    map!.addOverlay(overlay);

    const fullscreen = new FullScreen();
    map!.addControl(fullscreen);

    function displayTooltip(evt: any) {
      const pixel = evt.pixel;

      const feature = map!.forEachFeatureAtPixel(
        pixel,
        function (feature: any) {
          return feature;
        }
      );
      tooltip!.style.display = feature ? "" : "none";
      if (feature) {
        overlay!.setPosition(evt.coordinate);

        tooltip!.innerHTML = feature.get("name");
      }
    }

    map.on("pointermove", displayTooltip);
  }, []);
  let draw: Draw | null = null;

  const selectLineString = async () => {
    let layers = map!.getInteractions().getArray().length;
    if (layers == 9) {
      console.log(map);
      map!.removeOverlay(overlay!);

      const addInteraction = async () => {
        draw! = new Draw({
          source: source,
          type: "LineString",
        });
      };
      addInteraction();

      map!.addInteraction(draw!);
    } else {
      vector.getSource()!.clear(true)
      map!.removeInteraction(draw!);

      // map!.removeLayer(vector);
      map!.addOverlay(overlay!);
    }
  };
  const playEvent=(index:number)=>{
    if(index == 0){
      map!.removeLayer(berlin)
      map!.removeLayer(fuul)
    }
    if(index == 1){
      map!.addLayer(berlin)
      map!.removeLayer(fuul)
    }
    if(index == 2){
      map!.addLayer(fuul)
      map!.removeLayer(berlin)
    }
  }

  const sourceberlin = new Vectors({
    features: featuresss,
  });
  const featFullJson = new Vectors({
    features: featureFullJson,
  });
  let berlin = new Vector({
    source: sourceberlin,
    style: styleFunction,
  });
  let fuul = new Vector({
    source: featFullJson,
    style: styleFunction,
  });

  function nameButton() {
    setViewSites(!viewSites);
    if (viewSites) {
      setViewSites(!viewSites);
      return "מחק אתרים";
    } else {
      setViewSites(!viewSites);
      return "הצג אתרים";
    }
  }

  return (
    <div className="map">
      <div
        style={{ height: "77vh", width: "100%" }}
        id="map-container"
        className="map-container"
      />
      <div id="tooltip" className="tooltip"></div>
      {/* <button style={{ width: "60px", height: "30px" }} onClick={clickButten}>
        אישור
      </button>
      <button
        style={{ width: "60px", height: "30px" }}
        onClick={notClickButten}
      >
        ביטול
      </button> */}

      <div className="navButton">
        <Stack direction="row" justifyContent={"center"} spacing={2}>
          <Button
            variant="outlined"
            sx={{
              backgroundColor: "white",
              "&:hover": {
                backgroundColor: "white",
              },
            }}
            onClick={() => {
              const layers = map!.getLayers().getArray();
              if (layers.length > 3) {
                console.log(layers);
                map!.removeLayer(vectorLayer);
              } else {
                mapSource = new Vectors({
                  format: new GeoJSON(),
                  // url:"http://localhost:9000/geojson"
                  loader: vectorLoader!,
                });
                vectorLayer = new Vector({
                  source: mapSource,
                  style: styleFunction,

                  // title: 'b_layer',
                });
                map!.addLayer(vectorLayer);

                // setViewSites('מחק אתרים')
              }
            }}
          >
            הצג/מחק אתרים
          </Button>
          <Button
            variant="outlined"
            sx={{
              backgroundColor: "white",
              "&:hover": {
                backgroundColor: "white",
              },
            }}
            onClick={selectLineString}
          >
            בחר/מחק מרחק
          </Button>

          <SplitButton playEvent={playEvent}/>
        </Stack>
      </div>
    </div>
  );
};
export default AppMap;
